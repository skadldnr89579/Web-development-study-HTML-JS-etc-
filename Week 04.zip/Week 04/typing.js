let word_list = ['apple','mango','banana','orange'];
const word_display=document.querySelector(".word-display");
//console.dir(word_display);
word_display.innerText=word_list[0];
let count=0;
let word_input=document.querySelector(".word-input");
word_input.addEventListener("keydown",function(e){
    //alert("ok");
    //console.log(e.key);
    if(e.key==="Enter"){
        //alert("Enter");
        //console.dir(word_input.value);
        if(word_display.innerText===word_input.value){
            //alert("same");
            count=count+1;
            word_display.innerText=word_list[count];
        }
    }

})

function add (x,y){
    return x+y;
}

let result=add(3,5);
let result2=add(5,5);

console.log(result);
console.log(result2);
